# AutoVisitor
# Pkg install git
# git clone https://github.com/TlaZz/AutoVisitor
# cd AutoVisitor
# pkg install python
# pkg install python2
# python2 zz.py proxylist.txt
